from distutils.core import setup

setup(
	name = 'nester',
	version = '1.0.0',
	py_modules = ['nester'],
	author = 'Parth',
	author_email = 'parthjain.in@gmail.com',
	url = 'http://www.gmail.com',
	description = 'A simple printing function',
)